#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        return 1;
    } else if (pid == 0) {
        // Child process
        printf("Child (PID %d) is about to exit...\n", getpid());
        exit(42); // Exit with a specific status code
    } else {
        // Parent process
        int status;
        waitpid(pid, &status, 0); // Wait for the specific child

        printf("Parent (PID %d) waited for child (PID %d)\n", getpid(), pid);
        if (WIFEXITED(status)) {
            printf("Child exited with status %d\n", WEXITSTATUS(status));
        }
    }

    return 0;
}
