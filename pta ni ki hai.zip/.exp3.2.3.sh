#!/bin/bash

echo "Please enter your name:"
read name

if [ -z "$name" ]; then
    echo "You didn't enter a name!"
else
    for i in {1..5}; do
        echo "Hello, $name! ($i)"
    done
fi
