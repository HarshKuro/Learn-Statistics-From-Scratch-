#!/bin/bash

echo "Please enter your name:"
read name

if [ -z "$name" ]; then 
    echo "You didn't enter a name!"
else
    echo "Hello, $name!"
fi
